<footer class = "footer">
	<hr />
	<div id="paddingcopyright">
		<h6 align="right">Copyright &copy; 2015. Fakultas Teknologi Informasi Universitas YARSI. All Right Reserved</h6>
	</div>
</footer>